package formui

import (
	"strconv"
	"strings"

	"github.com/subhasundardas/gofar/framework/form"
)

// fieldID returns the HTML id attribute for a field.
// Uses field.Key as the id to ensure uniqueness.
func fieldID(field form.UIField) string {
	return field.Key
}

// wrapperID returns a deterministic id for the outer <div>.
// Used so Datastar effects and error messages can target it directly.
func wrapperID(fieldKey string) string {
	return "wrapper-" + fieldKey
}

// hintID returns the id for the hint/help text element.
// Wired to input's aria-describedby.
func hintID(fieldKey string) string {
	return "hint-" + fieldKey
}

// errorID returns the id for the error message element.
// Wired to input's aria-errormessage.
func errorID(fieldKey string) string {
	return "error-" + fieldKey
}

// fieldType maps form.FieldType to HTML input type attribute.
// Anything unrecognized defaults to "text".
func fieldType(t form.FieldType) string {
	switch t {
	case form.Email:
		return "email"
	case form.Password:
		return "password"
	case form.Date:
		return "date"
	case form.Time:
		return "time"
	case form.DateTime:
		return "datetime-local"
	case form.File:
		return "file"
	case form.URL:
		return "url"
	case form.Phone:
		return "tel"
	case form.Color:
		return "color"
	case form.Number:
		return "number"
	case form.Hidden:
		return "hidden"
	default:
		return "text"
	}
}

// liveUpdateAttr returns the Datastar input-debounce attribute for live field updates.
// Empty string if no endpoint is configured (caller should wrap in `if`).
//
// Format: @post('/path/to/validate')
func liveUpdateAttr(endpoint string) string {
	if endpoint == "" {
		return ""
	}
	return "@post('" + endpoint + "')"
}

// visibilityAttr returns the HTML hidden attribute if field is not visible.
// Used in the switch block: if !field.Visible { hidden }
func visibilityAttr(visible bool) string {
	if !visible {
		return "hidden"
	}
	return ""
}

// disabledAttr returns "disabled" if field is disabled, else "".
func disabledAttr(disabled bool) string {
	if disabled {
		return "disabled"
	}
	return ""
}

// readonlyAttr returns "readonly" if field is read-only, else "".
func readonlyAttr(readOnly bool) string {
	if readOnly {
		return "readonly"
	}
	return ""
}

// toClass is a helper to apply a class conditionally.
// Usage: { toClass("class-name", condition) }
// Returns "class-name" if condition is true, "" otherwise.
func toClass(class string, condition bool) string {
	if condition {
		return class
	}
	return ""
}

// concatClasses joins multiple class strings, filtering out empty ones.
// Useful for combining base classes with conditional ones.
func concatClasses(classes ...string) string {
	var parts []string
	for _, c := range classes {
		if c != "" {
			parts = append(parts, c)
		}
	}
	return strings.Join(parts, " ")
}

// stringValue converts any value to its string representation for form fields.
// Matches the form engine's contract.
func stringValue(v any) string {
	if v == nil {
		return ""
	}
	return form.Stringify(v)
}

// boolValue checks if a value represents "true".
// Used for checkboxes.
func boolValue(v any) bool {
	str := stringValue(v)
	return str == "true" || str == "1" || str == "yes"
}

// toString safely converts a value to string.
func toString(v any) string {
	if v == nil {
		return ""
	}
	switch val := v.(type) {
	case string:
		return val
	case int:
		return strconv.Itoa(val)
	case float64:
		return strconv.FormatFloat(val, 'f', -1, 64)
	case bool:
		if val {
			return "true"
		}
		return "false"
	default:
		return form.Stringify(v)
	}
}

// ariaDescribedBy returns space-separated ids for aria-describedby.
// Includes both hint and error message ids if they exist.
func ariaDescribedBy(fieldName string, hasHint bool, hasError bool) string {
	var ids []string
	if hasHint {
		ids = append(ids, hintID(fieldName))
	}
	if hasError {
		ids = append(ids, errorID(fieldName))
	}
	return strings.Join(ids, " ")
}
