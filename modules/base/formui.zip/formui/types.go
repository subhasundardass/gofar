package formui

// FieldProps carries presentation-level options for widget components.
// These are separate from the semantic form.UIField so the form engine stays
// decoupled from rendering details.
//
// A typical pattern has two layers:
//
//  1. Module-level defaults — built once at boot via DefaultProps() and
//     passed to every formui.Field call on every page.
//  2. Per-call overrides — merged via Merge() so only differences are overridden.
//
// Example:
//
//	defaultProps := formui.DefaultProps()
//	customProps := defaultProps.Merge(&formui.FieldProps{ InputClass: "border-blue-500" })
//	@formui.Field(field, customProps)
type FieldProps struct {
	// ── CSS Classes ──────────────────────────────────────────
	// Outer wrapper div
	WrapperClass string
	// Label element
	LabelClass string
	// Input/select/textarea/checkbox element
	InputClass string
	// Error message span
	ErrorClass string
	// Hint/help text span
	HintClass string
}

// DefaultProps returns FieldProps with sensible defaults.
// Call this once at module init and pass to all formui.Field calls.
func DefaultProps() FieldProps {
	return FieldProps{
		WrapperClass: "form-group mb-4",
		LabelClass:   "block text-sm font-semibold text-gray-700 mb-2",
		InputClass:   "w-full border border-gray-300 rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500",
		ErrorClass:   "text-red-600 text-sm mt-1",
		HintClass:    "text-gray-500 text-xs mt-1",
	}
}

// CompactProps returns a compact, inline-friendly style.
// Use for forms where space is constrained.
func CompactProps() FieldProps {
	return FieldProps{
		WrapperClass: "flex gap-2 items-center mb-2",
		LabelClass:   "font-semibold w-32 shrink-0 text-sm",
		InputClass:   "border rounded px-2 py-1 text-xs flex-1",
		ErrorClass:   "text-red-500 text-xs",
		HintClass:    "text-gray-400 text-xs",
	}
}

// InlineProps returns a minimal inline style (label: value).
// Use for inline forms or field groups in a row.
func InlineProps() FieldProps {
	return FieldProps{
		WrapperClass: "flex items-center gap-1 flex-1",
		LabelClass:   "text-sm font-semibold shrink-0 w-32",
		InputClass:   "border-b border-gray-300 px-1 py-0.5 text-sm flex-1",
		ErrorClass:   "text-red-500 text-xs",
		HintClass:    "text-gray-400 text-xs",
	}
}

// Merge applies override props on top of defaults.
// Returns a new FieldProps with non-empty override values replacing defaults.
func (p FieldProps) Merge(override *FieldProps) FieldProps {
	if override == nil {
		return p
	}
	result := p
	if override.WrapperClass != "" {
		result.WrapperClass = override.WrapperClass
	}
	if override.LabelClass != "" {
		result.LabelClass = override.LabelClass
	}
	if override.InputClass != "" {
		result.InputClass = override.InputClass
	}
	if override.ErrorClass != "" {
		result.ErrorClass = override.ErrorClass
	}
	if override.HintClass != "" {
		result.HintClass = override.HintClass
	}
	return result
}

// WithWrapperClass returns a copy with WrapperClass overridden.
func (p FieldProps) WithWrapperClass(class string) FieldProps {
	p.WrapperClass = class
	return p
}

// WithLabelClass returns a copy with LabelClass overridden.
func (p FieldProps) WithLabelClass(class string) FieldProps {
	p.LabelClass = class
	return p
}

// WithInputClass returns a copy with InputClass overridden.
func (p FieldProps) WithInputClass(class string) FieldProps {
	p.InputClass = class
	return p
}

// WithErrorClass returns a copy with ErrorClass overridden.
func (p FieldProps) WithErrorClass(class string) FieldProps {
	p.ErrorClass = class
	return p
}

// WithHintClass returns a copy with HintClass overridden.
func (p FieldProps) WithHintClass(class string) FieldProps {
	p.HintClass = class
	return p
}
